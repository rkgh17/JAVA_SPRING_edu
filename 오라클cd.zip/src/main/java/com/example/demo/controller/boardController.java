package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class boardController {

    //템플릿엔진(jsp..)에서 요청한 url주소와 연결과는 어노테이션
    @GetMapping("/board/list")
    public String list(Model model) {
        String name = "김준석";
        name += "교사";
//        model.addAllAttributes("name", name);
        return "/board/list";
    }

    @GetMapping("/borad/calc")
    public void calc() {

    }
}
